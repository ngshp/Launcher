using System;
using System.Windows;
using System.Windows.Forms;
using Application = System.Windows.Application;
using MessageBox = System.Windows.MessageBox;

namespace NGPB.Launcher;

/// <summary>
/// Mengelola ikon system tray. Sebelumnya minimize cuma taruh window di
/// taskbar biasa — sekarang bisa disembunyikan penuh ke tray (kalau
/// LauncherSettings.MinimizeToTray = true), dengan menu klik kanan untuk
/// membuka lagi atau keluar total.
/// </summary>
public sealed class TrayIconManager : IDisposable
{
    private readonly NotifyIcon _notifyIcon;
    private readonly Window _window;

    public TrayIconManager(Window window)
    {
        _window = window;

        var icon = System.Drawing.Icon.ExtractAssociatedIcon(
            System.Diagnostics.Process.GetCurrentProcess().MainModule!.FileName!) ?? System.Drawing.SystemIcons.Application;

        var menu = new ContextMenuStrip();
        menu.Items.Add("Open PBNG Launcher", null, (_, _) => RestoreWindow());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => Application.Current.Shutdown());

        _notifyIcon = new NotifyIcon
        {
            Icon = icon,
            Text = "PBNG Launcher",
            Visible = false,
            ContextMenuStrip = menu,
        };
        _notifyIcon.DoubleClick += (_, _) => RestoreWindow();
    }

    public void MinimizeToTray()
    {
        _notifyIcon.Visible = true;
        _window.Hide();
        _notifyIcon.ShowBalloonTip(1500, "PBNG Launcher",
            "Still running in the background. Double-click the tray icon to reopen.", ToolTipIcon.Info);
    }

    private void RestoreWindow()
    {
        _window.Show();
        _window.WindowState = WindowState.Normal;
        _window.Activate();
        _notifyIcon.Visible = false;
    }

    public void Dispose()
    {
        _notifyIcon.Visible = false;
        _notifyIcon.Dispose();
    }
}
