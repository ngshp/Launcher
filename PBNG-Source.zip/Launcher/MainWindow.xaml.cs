using System;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using NGPB.Launcher.Services;

namespace NGPB.Launcher;

public partial class MainWindow : Window
{
    private const string LauncherAppVersion = "18.2.0";

    private readonly LauncherConfig _config;
    private readonly PbngApiClient _api;
    private readonly LauncherSettings _settings;
    private readonly TrayIconManager _tray;
    private readonly DispatcherTimer _onlineStatsTimer;
    private bool _patchReady;
    private bool _reallyExit;
    private string? _pendingUpdateDownloadUrl;

    public MainWindow()
    {
        InitializeComponent();
        _config = LoadConfig();
        _api = new PbngApiClient(_config.ApiBaseUrl);
        _settings = LauncherSettings.Load();
        Loc.CurrentLanguage = _settings.Language;
        _tray = new TrayIconManager(this);

        // Set teks awal sesuai bahasa pilihan sebelum data dari server datang,
        // supaya tidak "kedip" dari default XAML (selalu Inggris) ke bahasa
        // yang dipilih pemain.
        NewsPlaceholderText.Text = Loc.T("NewsLoading");
        ServerStatus.Text = Loc.T("ServerChecking");
        PatchStatusText.Text = Loc.T("PatchChecking");
        ReadyStatusTitle.Text = Loc.T("ReadyPreparing");
        ReadyStatusSubtitle.Text = Loc.T("ReadySubPreparing");
        StartGameButton.Content = Loc.T("StartChecking");

        _onlineStatsTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(10) };
        _onlineStatsTimer.Tick += async (_, _) => await RefreshOnlineStatsAsync();

        Loaded += async (_, _) => await OnLoadedAsync();
        Closing += MainWindow_Closing;
        Closed += (_, _) => { _onlineStatsTimer.Stop(); _tray.Dispose(); };
    }

    // ------------------------------------------------------------------
    // Drag window
    // ------------------------------------------------------------------
    private void HeaderBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed)
        {
            try { DragMove(); } catch { /* abaikan kalau state sedang tidak valid untuk drag */ }
        }
    }

    // ------------------------------------------------------------------
    // Minimize ke tray (kalau diaktifkan) atau taskbar biasa; Exit sungguhan
    // ------------------------------------------------------------------
    private void MinimizeButton_Click(object sender, RoutedEventArgs e)
    {
        if (_settings.MinimizeToTray) _tray.MinimizeToTray();
        else WindowState = WindowState.Minimized;
    }

    private void ExitButton_Click(object sender, RoutedEventArgs e)
    {
        _reallyExit = true;
        Close();
    }

    private void MainWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        // Klik tombol X di title bar custom kita anggap sebagai keluar
        // sungguhan (bukan minimize-to-tray) supaya perilakunya jelas dan
        // tidak membingungkan pemain yang tidak tahu ada fitur tray.
        if (!_reallyExit && _settings.MinimizeToTray)
        {
            // dibiarkan tetap keluar seperti biasa; tray hanya dipakai
            // lewat tombol Minimize, bukan tombol Close.
        }
    }

    // ------------------------------------------------------------------
    // Konfigurasi
    // ------------------------------------------------------------------
    private static LauncherConfig LoadConfig()
    {
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, "Configuration", "launcher.config.json");
            if (!File.Exists(path))
                path = Path.Combine(AppContext.BaseDirectory, "launcher.config.json");

            var json = File.ReadAllText(path);
            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            return JsonSerializer.Deserialize<LauncherConfig>(json, options) ?? LauncherConfig.Default;
        }
        catch
        {
            return LauncherConfig.Default;
        }
    }

    // ------------------------------------------------------------------
    // Startup
    // ------------------------------------------------------------------
    private async Task OnLoadedAsync()
    {
        if (!_settings.EulaAccepted)
        {
            var eula = new EulaWindow { Owner = this };
            if (eula.ShowDialog() != true)
            {
                _reallyExit = true;
                Close();
                return;
            }
            _settings.EulaAccepted = true;
            _settings.Save();
        }

        await RefreshServerStatusAsync();
        await RefreshNewsAsync();
        await RefreshLauncherVersionAsync();
        await RefreshPatchStatusAsync();
        await RefreshOnlineStatsAsync();
        _onlineStatsTimer.Start();
    }

    private async Task RefreshServerStatusAsync()
    {
        bool healthy = await _api.HealthAsync();
        ServerStatus.Text = healthy ? Loc.T("ServerOk") : Loc.T("ServerUnreachable");
    }

    private async Task RefreshOnlineStatsAsync()
    {
        var stats = await _api.GetOnlineStatsAsync();
        OnlinePlayersText.Text = stats is null
            ? "OFFLINE"
            : $"{stats.Online:N0} PLAYERS  ·  PEAK {stats.PeakToday:N0}";
    }

    // ------------------------------------------------------------------
    // Berita
    // ------------------------------------------------------------------
    private async Task RefreshNewsAsync()
    {
        var articles = await _api.GetNewsAsync();
        if (articles is null || articles.Count == 0)
        {
            NewsPlaceholderText.Text = Loc.T("NewsLoadFailed");
            return;
        }

        NewsItemsControl.ItemsSource = articles.ConvertAll(NewsItemViewModel.FromArticle);
        NewsPlaceholderText.Visibility = Visibility.Collapsed;
    }

    // ------------------------------------------------------------------
    // Versi launcher + auto-update
    // ------------------------------------------------------------------
    private async Task RefreshLauncherVersionAsync()
    {
        var info = await _api.GetLauncherVersionAsync();
        if (info is null) return;

        VersionText.Text = $"VERSION {LauncherAppVersion}";

        if (!string.Equals(info.LatestVersion, LauncherAppVersion, StringComparison.OrdinalIgnoreCase))
        {
            VersionSubText.Text = Loc.T("VersionNewAvailable", info.LatestVersion);
            _pendingUpdateDownloadUrl = info.DownloadUrl;
            UpdateAvailableText.Text = Loc.T("UpdateAvailableLabel");
            UpdateAvailableText.Visibility = Visibility.Visible;
        }
        else
        {
            VersionSubText.Text = Loc.T("VersionLatest");
            UpdateAvailableText.Visibility = Visibility.Collapsed;
        }
    }

    private async void UpdateAvailableText_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (string.IsNullOrEmpty(_pendingUpdateDownloadUrl)) return;

        var confirm = MessageBox.Show(
            "A new launcher version is available. Download and restart now?",
            "PBNG Launcher Update", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (confirm != MessageBoxResult.Yes) return;

        UpdateAvailableText.Text = Loc.T("UpdateDownloading");
        bool ok = await UpdateManager.DownloadAndApplyUpdateAsync(_pendingUpdateDownloadUrl);
        if (ok)
        {
            _reallyExit = true;
            Application.Current.Shutdown();
        }
        else
        {
            UpdateAvailableText.Text = Loc.T("UpdateAvailableLabel");
        }
    }

    // ------------------------------------------------------------------
    // Patch progress — cek ruang disk dulu, lalu download+verify (resume-able)
    // ------------------------------------------------------------------
    private async Task RefreshPatchStatusAsync()
    {
        SetStartButtonBusy(Loc.T("StartChecking"));
        ReadyStatusTitle.Text = Loc.T("ReadyPreparing");
        ReadyStatusTitle.Foreground = System.Windows.Media.Brushes.Goldenrod;
        ReadyStatusSubtitle.Text = Loc.T("ReadySubPreparing");

        try
        {
            var manifest = await _api.GetManifestAsync();

            if (manifest is null || manifest.Files.Count == 0)
            {
                PatchStatusText.Text = Loc.T("PatchUpToDate");
                DownloadProgress.Value = 100;
                PatchPercentText.Text = "100%";
                DownloadedText.Text = "Downloaded: up to date";
                SpeedText.Text = "";
            }
            else
            {
                long totalSize = 0;
                foreach (var f in manifest.Files) totalSize += f.Size;

                string gameDir = Path.Combine(AppContext.BaseDirectory, "Game");
                long freeSpace = PbngApiClient.GetAvailableFreeBytes(gameDir);
                if (freeSpace < totalSize)
                {
                    PatchStatusText.Text = Loc.T("PatchNoDiskSpace");
                    ServerStatus.Text =
                        $"Need {totalSize / 1_000_000_000.0:0.00} GB but only " +
                        $"{freeSpace / 1_000_000_000.0:0.00} GB free. Free up space and reopen the launcher.";
                    ReadyStatusTitle.Text = Loc.T("ReadyDiskLow");
                    ReadyStatusTitle.Foreground = System.Windows.Media.Brushes.IndianRed;
                    ReadyStatusSubtitle.Text = Loc.T("ReadySubDiskLow");
                    SetStartButtonBusy(Loc.T("StartNoDiskSpace"));
                    return;
                }

                PatchStatusText.Text = Loc.T("PatchDownloading", manifest.Version);

                long completedBytes = 0;
                var stopwatch = Stopwatch.StartNew();

                foreach (var file in manifest.Files)
                {
                    string destination = Path.Combine(gameDir, file.Path);
                    long fileStartBytes = completedBytes;

                    var progress = new Progress<double>(pct =>
                    {
                        long fileBytesNow = (long)(file.Size * pct / 100.0);
                        long overallBytes = fileStartBytes + fileBytesNow;
                        double overallPct = totalSize > 0 ? overallBytes * 100.0 / totalSize : pct;
                        double elapsedSec = Math.Max(stopwatch.Elapsed.TotalSeconds, 0.1);
                        double speedMbps = overallBytes / 1_000_000.0 / elapsedSec;
                        UpdatePatchUi(overallPct, overallBytes, totalSize, speedMbps);
                    });

                    await _api.DownloadAndVerifyAsync(file, destination, progress);
                    completedBytes += file.Size;
                }

                PatchStatusText.Text = Loc.T("PatchUpToDate");
                DownloadProgress.Value = 100;
                PatchPercentText.Text = "100%";
            }

            _patchReady = true;
            ReadyStatusTitle.Text = Loc.T("ReadyGood");
            ReadyStatusTitle.Foreground = System.Windows.Media.Brushes.MediumSeaGreen;
            ReadyStatusSubtitle.Text = Loc.T("ReadySubGood");
            SetStartButtonReady();
        }
        catch (Exception ex)
        {
            PatchStatusText.Text = Loc.T("PatchFailed");
            ServerStatus.Text = "Could not reach patch server: " + ex.Message;
            ReadyStatusTitle.Text = Loc.T("ReadyFailed");
            ReadyStatusTitle.Foreground = System.Windows.Media.Brushes.IndianRed;
            ReadyStatusSubtitle.Text = Loc.T("ReadySubFailed");
            SetStartButtonBusy(Loc.T("StartUpdateRequired"));
        }
    }

    private void UpdatePatchUi(double pct, long downloadedBytes, long totalBytes, double speedMbps)
    {
        Dispatcher.Invoke(() =>
        {
            DownloadProgress.Value = Math.Clamp(pct, 0, 100);
            PatchPercentText.Text = $"{pct:0}%";
            DownloadedText.Text =
                $"Downloaded: {downloadedBytes / 1_000_000_000.0:0.00} GB / {totalBytes / 1_000_000_000.0:0.00} GB";
            SpeedText.Text = $"Speed: {speedMbps:0.0} MB/s";
        });
    }

    private void SetStartButtonBusy(string label)
    {
        StartGameButton.IsEnabled = false;
        StartGameButton.FontSize = 28;
        StartGameButton.Content = label;
    }

    private void SetStartButtonReady()
    {
        StartGameButton.IsEnabled = true;
        StartGameButton.FontSize = 38;
        StartGameButton.Content = Loc.T("StartReady");
    }

    // ------------------------------------------------------------------
    // Start Game
    // ------------------------------------------------------------------
    private async void StartGameButton_Click(object sender, RoutedEventArgs e)
    {
        if (!_patchReady) return;

        StartGameButton.IsEnabled = false;
        string originalText = Loc.T("StartReady");

        try
        {
            if (!LauncherStartupGuard.ValidateClientPath(out string guardMessage))
            {
                ServerStatus.Text = guardMessage;
                MessageBox.Show(
                    "Game client (ngpb-client.exe) was not found under the Game\\ folder.\n\n" +
                    "Build the GameClient project and copy the output there first.",
                    "PBNG Launcher", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string? token = SessionStore.Load();
            if (token is not null)
            {
                StartGameButton.Content = Loc.T("StartResuming");
                bool stillValid = await _api.ValidateTokenAsync(token);
                if (!stillValid) { SessionStore.Clear(); token = null; }
            }

            if (token is null)
            {
                var login = new LoginWindow(_api) { Owner = this };
                if (login.ShowDialog() != true)
                    return;

                StartGameButton.Content = Loc.T("StartSigningIn");
                var outcome = await _api.LoginAsync(login.Username, login.Password);
                if (!outcome.Success || outcome.Response is null)
                {
                    MessageBox.Show(outcome.ErrorMessage ?? "Login failed.",
                        "PBNG Launcher", MessageBoxButton.OK,
                        outcome.RateLimited ? MessageBoxImage.Warning : MessageBoxImage.Error);
                    return;
                }

                token = outcome.Response.AccessToken;
                if (login.RememberMe) SessionStore.Save(token);
            }

            StartGameButton.Content = Loc.T("StartLaunching");
            var result = new GameClientLauncher().Start(token, _config.ApiBaseUrl);
            if (result == GameClientLauncher.LaunchResult.AlreadyRunning)
            {
                ServerStatus.Text = Loc.T("GameAlreadyRunning");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Could not start the game: " + ex.Message,
                "PBNG Launcher", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            StartGameButton.Content = originalText;
            StartGameButton.IsEnabled = true;
        }
    }

    private async void CheckServerButton_Click(object sender, RoutedEventArgs e)
    {
        ServerStatus.Text = Loc.T("ServerChecking");
        await RefreshServerStatusAsync();
    }

    // ------------------------------------------------------------------
    // Nav
    // ------------------------------------------------------------------
    private void WebsiteButton_Click(object sender, RoutedEventArgs e) => OpenUrl("https://example.com");
    private void YoutubeButton_Click(object sender, RoutedEventArgs e) => OpenUrl("https://youtube.com");
    private void DiscordButton_Click(object sender, RoutedEventArgs e) => OpenUrl("https://discord.com");
    private void FacebookButton_Click(object sender, RoutedEventArgs e) => OpenUrl("https://facebook.com");

    private static void OpenUrl(string url) =>
        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });

    private void ProfileButton_Click(object sender, RoutedEventArgs e) =>
        MessageBox.Show("Profile integration will be added without changing this layout.", "PBNG Launcher");

    private void SettingsButton_Click(object sender, RoutedEventArgs e)
    {
        var settingsWindow = new SettingsWindow(_settings) { Owner = this };
        settingsWindow.ShowDialog();
    }
}

public sealed record LauncherConfig(string ApiBaseUrl, string PatchManifestPath, string GameExecutable, string Version)
{
    public static LauncherConfig Default => new(
        "http://127.0.0.1:5182/", "api/patch/manifest", "Game/ngpb-client.exe", "18.2.0");
}
