# PBNG V18.2 — Master Integration

Ini adalah hasil penggabungan 3 paket sebelumnya
(`ORIGINAL-CLIENT-V0_1`, `START-GAME-INTEGRATION`, `SECURITY-INTEGRATED-CLIENT-LAUNCHER`)
menjadi satu solution .NET yang saling terhubung ujung ke ujung — bukan lagi
potongan-potongan terpisah.

## Apa yang berubah dari 3 paket asal

Sebelumnya ketiga paket itu benar secara sintaks tapi **belum saling
tersambung**:

| Sebelum | Sesudah |
|---|---|
| `StartGameButton_Click` cuma munculkan `MessageBox` "pending" | Benar-benar login ke server → ambil launch ticket → jalankan `ngpb-client.exe` |
| `PbngApiClient` dan `AuthPatchServer` sudah ada tapi tidak dipanggil dari mana pun | Dipanggil dari `MainWindow.xaml.cs` saat startup (cek server, cek/patch update) dan saat Start Game (login) |
| `GameHandshakeEndpoint.cs` cuma dokumentasi/kontrak kosong | Diimplementasikan jadi endpoint nyata `GET /api/game/handshake` di server |
| `GameWindow` di GameClient cuma teks statis "Secure session established." | Benar-benar memanggil `/api/game/handshake` ke server dan menampilkan hasilnya |
| Jumlah "Players Online" di launcher = teks statis dari desain | Diambil dari endpoint baru `GET /api/stats/online` (dihitung dari token/launch-ticket aktif di server) |
| Downloaded/Speed di patch progress = teks statis | Diupdate real-time selama proses download+verifikasi SHA-256 berjalan |

## Alur menyalakan aplikasi

```
Pemain jalankan:  PBNG Security Bootstrapper.exe
                        │  (2 layar loading verifikasi)
                        ▼
                  NG PB Launcher.exe
                        │  - cek /api/health
                        │  - cek /api/patch/manifest, download file yg beda hash
                        │  - poll /api/stats/online tiap 10 detik
                        │
                  klik START GAME
                        │  - buka jendela login
                        │  - POST /api/auth/login  -> dapat launch ticket
                        │  - jalankan Game\ngpb-client.exe
                        │    (kirim ticket lewat environment variable)
                        ▼
                  ngpb-client.exe
                        │  - security gate: cek ticket ada
                        │  - GET /api/game/handshake dengan Bearer ticket
                        ▼
                  GameWindow (jendela game, saat ini masih shell)
```

Server (`PBNG.AuthPatchServer`) berjalan terpisah — di komputer/VPS kamu
sendiri, bukan di komputer pemain. Semua komponen di atas hanya bisa
berjalan penuh kalau server ini menyala dan bisa diakses oleh launcher.

## Struktur folder

```
PBNG-MASTER/
├── PBNG.sln                     <- buka ini di Visual Studio, atau build via CLI
├── build-all.ps1                <- build semua sekaligus + susun folder Deploy/
├── SecurityBootstrapper/        <- exe pertama yang dijalankan pemain
├── Launcher/                    <- NGPB.Launcher (UI master, sudah disambungkan)
│   ├── MainWindow.xaml          <- tampilan (tidak diubah dari desain asli)
│   ├── MainWindow.xaml.cs       <- logika (ditulis ulang, sekarang benar-benar jalan)
│   ├── LoginWindow.xaml(.cs)    <- baru: jendela login sebelum start game
│   ├── Services/PbngApiClient.cs
│   ├── GameClientLauncher.cs
│   ├── LauncherStartupGuard.cs
│   └── Game/                    <- ngpb-client.exe hasil build ditaruh di sini
├── GameClient/                  <- ngpb-client.exe (WPF + security gate)
└── Server/PBNG.AuthPatchServer/ <- auth + patch + stats + handshake server
```

## Cara build (di Windows, butuh .NET 8 SDK)

**Catatan penting:** build pertama kali butuh koneksi internet, karena beberapa package NuGet berikut perlu di-download otomatis oleh `dotnet restore`/`dotnet build`:
- `Microsoft.Data.Sqlite` (database akun di server)
- `Serilog.AspNetCore` (logging di server)
- `System.Security.Cryptography.ProtectedData` (enkripsi sesi login di launcher)

Setelah restore pertama berhasil, build selanjutnya bisa offline.

Paling gampang, jalankan satu perintah ini dari folder `PBNG-MASTER`:

```powershell
powershell -ExecutionPolicy Bypass -File build-all.ps1
```

Ini akan build ketiga exe (GameClient dulu, lalu Launcher, lalu
SecurityBootstrapper) dan menyusun semuanya ke folder `Deploy\` beserta
server-nya.

Atau build manual satu-satu:

```powershell
cd Server\PBNG.AuthPatchServer
dotnet run
```
```powershell
cd GameClient
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
# copy hasil ngpb-client.exe ke Launcher\Game\
```
```powershell
cd Launcher
dotnet run
```

## Build otomatis lewat GitHub Actions (tanpa perlu Windows/dotnet di komputer sendiri)

### 📱 Cara tercepat kalau kamu cuma pegang HP (upload 1 file zip saja)

Pakai file **`PBNG-Source.zip`** (bukan yang `PBNG-V18.2-MASTER-INTEGRATED.zip`) — isinya sama tapi tanpa folder pembungkus, supaya pas di-extract otomatis oleh GitHub Actions langsung jadi isi repo.

1. Buat repo baru di GitHub (kosong, jangan centang "Add README")
2. Di repo kosong itu, tap **"uploading an existing file"**
3. Tap area upload → pilih **`PBNG-Source.zip`** dari HP kamu (cukup 1 file ini, tidak perlu extract dulu) → **Commit changes**
4. Balik ke halaman utama repo, tap **Add file → Create new file**
5. Di kotak nama file, ketik persis: `.github/workflows/build.yml` (GitHub otomatis buat foldernya)
6. Paste isi workflow (saya kasih di bawah) → **Commit changes**
7. Buka tab **Actions** → workflow otomatis jalan (dia akan extract `PBNG-Source.zip` itu sendiri sebelum build) → tunggu ✅ → download hasilnya di bagian **Artifacts**

Isi untuk file `.github/workflows/build.yml` (copy semua ini):

```yaml
name: Build PBNG Launcher

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]
  workflow_dispatch:

jobs:
  build:
    runs-on: windows-latest
    steps:
      - name: Checkout kode
        uses: actions/checkout@v4

      - name: "Extract source.zip kalau ada (skenario upload 1 file dari HP)"
        shell: pwsh
        run: |
          $zip = Get-ChildItem -Path . -Filter *.zip -File | Select-Object -First 1
          if ($zip) {
            Write-Host "Ditemukan $($zip.Name), mengekstrak ke root repo..."
            Expand-Archive -Path $zip.FullName -DestinationPath . -Force
            Write-Host "Selesai extract."
          } else {
            Write-Host "Tidak ada file .zip di root repo, lanjut seperti biasa."
          }

      - name: Setup .NET 8 SDK
        uses: actions/setup-dotnet@v4
        with:
          dotnet-version: '8.0.x'

      - name: "Restore semua project (download NuGet: Sqlite, Serilog, ProtectedData)"
        run: dotnet restore PBNG.sln

      - name: Build solution (cek cepat semua project compile bersih)
        run: dotnet build PBNG.sln -c Release --no-restore

      - name: Publish semua exe + susun folder Deploy (pakai build-all.ps1)
        shell: pwsh
        run: ./build-all.ps1

      - name: Upload hasil build sebagai artifact
        uses: actions/upload-artifact@v4
        with:
          name: PBNG-Launcher-Windows
          path: Deploy/
          if-no-files-found: error
```

Kenapa 2 langkah upload terpisah (zip lalu workflow file manual)? Karena GitHub Actions **wajib** membaca file workflow langsung dari struktur folder repo (`.github/workflows/*.yml`) — tidak bisa dari dalam zip yang belum di-extract. Tapi kotak "Create new file" di GitHub bisa langsung bikin path bersarang begitu kamu ketik namanya, jadi ini tetap cuma 2x tap-tap dari HP, tanpa perlu app tambahan.

### 💻 Kalau punya laptop/komputer

Pakai file `PBNG-V18.2-MASTER-INTEGRATED.zip`, extract dulu, lalu upload SEMUA ISI folder hasil extract (termasuk folder `.github` yang sudah ada workflow-nya) ke repo — tidak perlu langkah manual bikin `build.yml` lagi karena sudah ikut dalam zip itu.

**Kenapa ini jalan padahal environment saya (Claude) tidak bisa build Windows:** GitHub Actions punya "runner" mesin Windows sungguhan yang disediakan gratis (`windows-latest`) khusus untuk kasus seperti ini — beda dengan sandbox Linux yang saya pakai untuk menulis kode.

**Catatan:**
- Runner Windows GitHub Actions gratis untuk repo public (unlimited), dan repo private dapat jatah menit gratis per bulan sebelum kena biaya tambahan.
- Kalau workflow gagal, buka log run yang merah di tab Actions — error compiler C# akan muncul lengkap di sana, tinggal kirim ke saya untuk diperbaiki.

## Menjalankan untuk dites

1. Jalankan server dulu: `cd Server\PBNG.AuthPatchServer && dotnet run`
   (default di `http://127.0.0.1:5182`, akun demo `test` / `ChangeMe123!`)
2. Build `GameClient`, copy `ngpb-client.exe` ke `Launcher\Game\`
3. Jalankan `Launcher` (`dotnet run` atau exe hasil publish)
4. Klik **START GAME**, login pakai akun demo → `ngpb-client.exe` akan
   terbuka dan menampilkan hasil handshake ke server

## Update kedua — bug fixes, polish, dan fitur tambahan

Setelah integrasi awal, launcher ini direview lagi dan diperbaiki/ditambah:

**Bug fixes:**
- Window sekarang bisa **di-drag** (klik-tahan area header) — sebelumnya `WindowStyle="None"` membuat window "menempel" di tengah layar
- Window sekarang **bisa di-resize** dan otomatis **scale** ke resolusi lebih kecil (dibungkus `Viewbox`, ada `MinWidth`/`MinHeight`) — sebelumnya fix 1536×1024 dan bakal terpotong di laptop resolusi kecil
- Tombol **START GAME** sekarang **terkunci** ("CHECKING FOR UPDATES...") sampai patch benar-benar selesai dicek — sebelumnya bisa diklik kapan saja meski file belum lengkap
- Username demo "test" yang tadinya ke-hardcode prefill di form login sudah dihapus

**Polish (state jujur):**
- Players online, status server, %patch, status ready — semua sekarang mulai dari state "Checking..." / "..." yang jujur, bukan angka statis yang seolah-olah data asli sebelum benar-benar di-refresh dari server

**Fitur baru:**
- **Berita dinamis** — 4 berita di kiri sekarang diambil dari endpoint baru `GET /api/news` (isi di `Server/PBNG.AuthPatchServer/Content/news.json`), bukan hardcode di XAML. Gambar thumbnail tetap dibundel lokal di launcher, dipetakan lewat `thumbnailKey`.
- **Notifikasi update launcher** — endpoint baru `GET /api/launcher/version`. Kalau versi launcher yang jalan berbeda dari versi yang "dideklarasikan" server, muncul teks kuning "Update available" di footer yang bisa diklik untuk buka link download.
- **Remember me** — checkbox di form login. Kalau dicentang, launch ticket disimpan terenkripsi (Windows DPAPI, `SessionStore.cs`) di `%AppData%\PBNG\session.dat`, supaya pemain tidak perlu login ulang setiap buka launcher. Ada opsi "Forget session" di tombol Settings.
- **Online players** sekarang beneran dari server (`GET /api/stats/online`, dihitung dari token aktif), bukan simulasi angka acak lagi.

### File/kelas baru yang ditambahkan di update ini

| File | Fungsi |
|---|---|
| `Launcher/SessionStore.cs` | Simpan/baca/hapus launch ticket terenkripsi (DPAPI) |
| `Launcher/NewsItemViewModel.cs` | Jembatan data berita dari server ke tampilan XAML |
| `Launcher/LoginWindow.xaml(.cs)` | Ditambah checkbox Remember Me |
| `Server/.../Services/NewsService.cs` | Baca daftar berita dari `Content/news.json` |
| `Server/.../Content/news.json` | Data berita (isi sama seperti sebelumnya, sekarang jadi data bukan kode) |
| `Server/.../Services/OnlineStatsService.cs` | Hitung player online dari token aktif |

### Catatan jujur soal batasan yang tersisa

- **Hero image (judul "PBNG THE NEXT ERA OF POINT BLANK") masih satu file gambar utuh** (`Hero_Master.png`) dengan teksnya sudah "baked in". Ini bukan sesuatu yang bisa diperbaiki lewat kode — perlu source art asli berlapis (teks terpisah dari background) dari desainer untuk bisa bikin teksnya dinamis/mudah diganti bahasa.
- Resize window sekarang berfungsi via `Viewbox`, tapi karena `WindowStyle="None"`, menarik dari tepi window untuk resize manual mungkin terasa "tipis" (area drag-nya sempit) dibanding window Windows biasa. Kalau ini terasa mengganggu, solusinya perlu custom hit-testing resize border (`WM_NCHITTEST`) — belum diimplementasikan di update ini.

## Update ketiga — kritis, quality-of-life, dan nice-to-have

Babak ketiga ini menambahkan hal-hal yang dibutuhkan supaya launcher terasa seperti produk sungguhan, bukan cuma demo:

**Kritis:**
- **Single-instance lock** — launcher tidak bisa dibuka 2x sekaligus (`App.xaml.cs`, Mutex bernama)
- **Cegah buka game 2x** — kalau `ngpb-client.exe` sudah jalan, klik Start Game lagi cuma bawa window game itu ke depan (`GameClientLauncher.cs`)
- **Resume download** — patch yang terputus di tengah jalan lanjut dari byte terakhir (HTTP Range request), tidak mulai dari 0 lagi
- **Rate limiting login** — 5x gagal berturut-turut → lockout 5 menit per kombinasi username+IP (`LoginRateLimiter.cs`)
- **Migrasi ke SQLite** — akun tidak lagi disimpan di file JSON polos yang rawan corrupt kalau diakses bersamaan (`AccountStore.cs` + `Microsoft.Data.Sqlite`, database di `Data/pbng.db`)

**Quality-of-life:**
- **Registrasi akun** — pemain bisa bikin akun sendiri lewat `RegisterWindow` (link "Create one" di form login), bukan cuma pakai 1 akun demo
- **System tray** — tombol Minimize sekarang bisa menyembunyikan launcher ke tray (bisa dimatikan di Settings)
- **Auto-update launcher** — klik notifikasi update → download otomatis → restart sendiri ke versi baru (`UpdateManager.cs`)
- **Cek ruang disk** sebelum mulai download patch, kasih pesan jelas kalau tidak cukup

**Nice-to-have:**
- **Logging server** — Serilog, log harian ke `Logs/server-YYYYMMDD.log` (server tidak lagi "buta" kalau ada masalah di production)
- **EULA/Terms of Service** — popup sekali di awal sebelum bisa login (`EulaWindow`, teksnya masih placeholder — **wajib diganti pengacara/tim legal sebelum rilis publik**)
- **Multi-bahasa (ID/EN)** — teks-teks dinamis (status server, progress patch, label tombol) sekarang mengikuti pilihan bahasa di Settings (`Localization.cs`/`Loc.T(...)`)
- **Settings window** — atur minimize-to-tray, bahasa, dan hapus sesi tersimpan

### Bug yang ditemukan & diperbaiki selama audit babak ketiga

| Bug | Perbaikan |
|---|---|
| `SecurityGateWindow`/`SecurityWindow` (bootstrapper) tidak bisa ditutup sama sekali kalau verifikasi gagal (tidak ada title bar, taskbar, atau tombol close) | Ditambah flag `_checking` — window hanya terkunci SELAMA proses verifikasi berjalan (~1 detik), setelah itu (berhasil atau gagal) boleh ditutup lewat Esc atau klik |
| `SecurityBootstrapper/SecurityWindow.xaml` — atribut `MouseLeftButtonDown="Window_MouseLeftButtonDown"` hilang di XAML padahal method-nya ada di code-behind, padahal teks di layar bilang "click to close" | Ditambahkan atribut yang hilang, sekarang klik beneran menutup window seperti yang dijanjikan teksnya |
| Setting **Language** di Settings tersimpan tapi tidak pernah benar-benar dipakai di mana pun (fitur "kosong") | Dibuat `Localization.cs` dan disambungkan ke semua teks dinamis di `MainWindow.xaml.cs` |
| `PbngApiClient.cs` tidak punya `using System.Net.Http;`/`using System.Threading;` — akan gagal compile di project WPF (`ImplicitUsings` project non-Web cuma cover 5 namespace dasar) | Ditambahkan kedua `using` yang hilang |

### Batasan jujur yang masih ada

- **HTTPS**: hanya redirect logic-nya yang ada (`app.UseHttpsRedirection()`); sertifikat TLS asli belum terpasang (lihat `appsettings.json` — ada template konfigurasi Kestrel yang tinggal diisi path sertifikat asli kamu)
- **Multi-bahasa** hanya mencakup teks yang di-set dinamis dari code, bukan teks statis yang sudah "dibakar" di XAML (WEBSITE, LATEST NEWS, PATCH PROGRESS, dst) — itu butuh refactor XAML ke ResourceDictionary per-bahasa
- **EULA masih placeholder** — wajib diganti Terms of Service & Kebijakan Privasi asli yang sudah ditinjau sebelum dipakai publik
- **Auto-update launcher** memindahkan file lewat script `.bat` sederhana (delay ~2 detik lalu overwrite) — cukup untuk kebanyakan kasus, tapi tidak seelegan installer MSI/Squirrel yang biasa dipakai aplikasi komersial

## Yang masih perlu kamu lengkapi sendiri

Ini bukan lagi kumpulan stub, tapi juga belum jadi game/produk final.
Yang masih perlu kamu isi:

- **Isi gameplay asli** — `ngpb-client.exe` saat ini masih "client shell":
  menampilkan jendela dan memverifikasi koneksi ke server, belum ada
  rendering, map, senjata, atau multiplayer sungguhan.
- **File patch nyata** — `manifest.json` di server saat ini kosong
  (`"files": []`). Isi dengan file game asli + hash SHA-256-nya supaya
  fitur download-patch di launcher benar-benar mengunduh sesuatu.
- ~~**Akun produksi** — pindahkan dari JSON ke database sungguhan~~ **Sudah selesai** di update ketiga (migrasi ke SQLite, lihat `AccountStore.cs`). Yang masih perlu: ganti akun demo `test/ChangeMe123!` sebelum rilis publik (atau hapus seeding otomatisnya).
- **HTTPS + hosting nyata** — server ini jalan di `http://127.0.0.1` untuk
  development. Untuk publik, perlu domain, sertifikat HTTPS asli (lihat
  template Kestrel di `appsettings.json`), dan hosting yang benar.
- **Anti-cheat nyata** — dua "security layer" di Bootstrapper/GameClient
  adalah gerbang UI (mencegah start tanpa ticket, mencegah tutup paksa
  saat verifikasi), **bukan** anti-cheat kernel-level. Untuk deteksi cheat
  sungguhan, itu pekerjaan terpisah di sisi server + client yang jauh
  lebih kompleks.

