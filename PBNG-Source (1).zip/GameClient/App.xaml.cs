using System.Windows;
namespace PBNG.GameClient;
public partial class App : Application { }
