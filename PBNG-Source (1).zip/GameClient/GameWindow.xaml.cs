using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Windows;

namespace PBNG.GameClient;

public partial class GameWindow : Window
{
    public GameWindow()
    {
        InitializeComponent();
        Loaded += async (_, _) => await VerifyGatewayAsync();
    }

    /// <summary>
    /// Mengulang logika handshake yang tadinya ada di ORIGINAL-CLIENT-V0_1
    /// (Program.cs versi console), sekarang dijalankan di jendela WPF ini
    /// setelah SecurityGateWindow meloloskan launch ticket.
    /// </summary>
    private async Task VerifyGatewayAsync()
    {
        string ticket = Environment.GetEnvironmentVariable("PBNG_LAUNCH_TICKET") ?? "";
        string gateway = Environment.GetEnvironmentVariable("PBNG_GAME_GATEWAY") ?? "http://127.0.0.1:5182";

        GatewayText.Text = $"Gateway: {gateway}";

        using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
        http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", ticket);

        try
        {
            var response = await http.GetAsync(gateway.TrimEnd('/') + "/api/game/handshake");
            StatusText.Text = response.IsSuccessStatusCode
                ? "Secure session established."
                : $"Gateway rejected client: {(int)response.StatusCode}";
        }
        catch (Exception ex)
        {
            StatusText.Text = "Gateway unavailable: " + ex.Message;
        }
    }
}
