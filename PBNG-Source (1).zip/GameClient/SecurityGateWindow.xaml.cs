using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
namespace PBNG.GameClient;
public partial class SecurityGateWindow : Window
{
    // _checking = true hanya selama animasi verifikasi berjalan (~1 detik),
    // supaya proses tidak bisa ditutup paksa di tengah pengecekan. Begini
    // sebelumnya (dari paket asli): flag ini bernama _verified dan TIDAK
    // PERNAH diset balik ke sesuatu yang mengizinkan Close() kalau
    // verifikasi gagal — jadi window jadi tidak bisa ditutup sama sekali
    // (tidak ada title bar, tidak muncul di taskbar, Alt+F4 pun diblokir
    // oleh handler Closing). Di sini closing HANYA diblokir selama
    // _checking, dan selalu diizinkan lagi begitu proses selesai —
    // baik itu berhasil maupun gagal.
    private bool _checking = true;

    public SecurityGateWindow()
    {
        InitializeComponent();
        Loaded += async (_, _) => await RunAsync();
        Closing += (_, e) => { if (_checking) e.Cancel = true; };
        KeyDown += (_, e) => { if (e.Key == Key.Escape && !_checking) Close(); };
    }

    private async Task RunAsync()
    {
        try
        {
            await LayerAsync(1, "SECURITY LOADING — LAYER 1", "Initializing client security...");
            await LayerAsync(2, "SECURITY VERIFICATION — LAYER 2", "Validating secure launch context...");

            string ticket = Environment.GetEnvironmentVariable("PBNG_LAUNCH_TICKET") ?? "";
            if (string.IsNullOrWhiteSpace(ticket))
            {
                StatusText.Text = "SECURE LAUNCH REQUIRED";
                Footer.Text = "Start ngpb-client.exe through the official PBNG launcher. (Press Esc or click to close)";
                return;
            }

            var main = new GameWindow();
            Application.Current.MainWindow = main;
            main.Show();
            Close();
        }
        catch
        {
            StatusText.Text = "SECURITY VERIFICATION FAILED";
            Footer.Text = "Game client startup was blocked. (Press Esc or click to close)";
        }
        finally
        {
            // Apa pun hasilnya (sukses, gagal, atau exception), verifikasi
            // sudah SELESAI di titik ini -> window boleh ditutup pengguna.
            _checking = false;
        }
    }

    private async Task LayerAsync(int layer, string title, string message)
    {
        LayerTitle.Text = title;
        StatusText.Text = message;
        for (int i = 0; i <= 100; i += 5)
        {
            Progress.Value = i;
            await Task.Delay(25);
            Dispatcher.Invoke(DispatcherPriority.Background, new Action(() => { }));
        }
    }

    // Klik di mana saja untuk menutup window, dipakai saat verifikasi gagal
    // (window ini WindowStyle="None" jadi tidak ada tombol X bawaan).
    private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (!_checking) Close();
    }
}
