param(
    [switch]$SkipServer
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$deploy = Join-Path $root "Deploy"

Write-Host "============================================"
Write-Host "  PBNG V18.2 - Build All"
Write-Host "============================================"

if (Test-Path $deploy) { Remove-Item $deploy -Recurse -Force }
New-Item -ItemType Directory -Path $deploy | Out-Null
New-Item -ItemType Directory -Path (Join-Path $deploy "Game") | Out-Null

# 1) GameClient (harus dibuild duluan supaya bisa dicopy ke Launcher\Game & Deploy\Game)
Write-Host "`n[1/4] Building GameClient (ngpb-client.exe)..."
Push-Location (Join-Path $root "GameClient")
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
Pop-Location
$gameClientOut = Join-Path $root "GameClient\bin\Release\net8.0-windows\win-x64\publish\ngpb-client.exe"
Copy-Item $gameClientOut (Join-Path $root "Launcher\Game\ngpb-client.exe") -Force
Copy-Item $gameClientOut (Join-Path $deploy "Game\ngpb-client.exe") -Force

# 2) Launcher
Write-Host "`n[2/4] Building Launcher (NG PB Launcher.exe)..."
Push-Location (Join-Path $root "Launcher")
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
Pop-Location
$launcherPublish = Join-Path $root "Launcher\bin\Release\net8.0-windows\win-x64\publish"
Copy-Item (Join-Path $launcherPublish "NG PB Launcher.exe") (Join-Path $deploy "NG PB Launcher.exe") -Force

# 3) SecurityBootstrapper
Write-Host "`n[3/4] Building SecurityBootstrapper (entry point)..."
Push-Location (Join-Path $root "SecurityBootstrapper")
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
Pop-Location
$bootstrapPublish = Join-Path $root "SecurityBootstrapper\bin\Release\net8.0-windows\win-x64\publish"
Copy-Item (Join-Path $bootstrapPublish "PBNG Security Bootstrapper.exe") (Join-Path $deploy "PBNG Security Bootstrapper.exe") -Force

# 4) Server (opsional, jalan terpisah - biasanya di VPS/host, bukan di PC pemain)
if (-not $SkipServer) {
    Write-Host "`n[4/4] Building Server (PBNG.AuthPatchServer)..."
    Push-Location (Join-Path $root "Server\PBNG.AuthPatchServer")
    dotnet publish -c Release -o (Join-Path $deploy "Server")
    Pop-Location
} else {
    Write-Host "`n[4/4] Skip build server (-SkipServer)."
}

Write-Host "`n============================================"
Write-Host "  SELESAI"
Write-Host "============================================"
Write-Host "Hasil ada di: $deploy"
Write-Host ""
Write-Host "Struktur untuk didistribusikan ke pemain:"
Write-Host "  Deploy\"
Write-Host "  |- PBNG Security Bootstrapper.exe   <- pemain jalankan ini"
Write-Host "  |- NG PB Launcher.exe"
Write-Host "  |- Game\ngpb-client.exe"
Write-Host ""
Write-Host "Server (Deploy\Server\) dijalankan terpisah di komputer/VPS kamu:"
Write-Host "  cd Deploy\Server"
Write-Host "  dotnet PBNG.AuthPatchServer.dll"
