using System.Collections.Generic;

namespace NGPB.Launcher;

/// <summary>
/// Lokalisasi ringan untuk teks yang di-set secara dinamis dari code-behind
/// (status server, status patch, label tombol Start Game, dsb).
///
/// KETERBATASAN JUJUR: ini TIDAK melokalisasi teks statis yang sudah
/// "dibakar" langsung di MainWindow.xaml (mis. "WEBSITE", "LATEST NEWS",
/// "PATCH PROGRESS", "SERVER STATUS"). Untuk melokalisasi itu juga,
/// perlu refactor lebih besar: pindahkan semua Text="..." di XAML ke
/// ResourceDictionary per-bahasa (mis. Strings.id.xaml / Strings.en.xaml)
/// dan bind lewat {DynamicResource}. Itu di luar cakupan perbaikan kali
/// ini karena menyentuh banyak bagian XAML "master" yang sudah disetujui
/// desainnya.
/// </summary>
public static class Loc
{
    public static string CurrentLanguage { get; set; } = "id";

    private static readonly Dictionary<string, (string Id, string En)> Strings = new()
    {
        ["ServerOk"] = ("Semua server berjalan normal.", "All servers are running smoothly."),
        ["ServerUnreachable"] = ("Server tidak terjangkau. Cek koneksi internetmu.", "Server unreachable. Check your connection and try again."),
        ["ServerChecking"] = ("Mengecek server...", "Checking server..."),

        ["PatchUpToDate"] = ("Sudah versi terbaru", "Up to date"),
        ["PatchChecking"] = ("Memeriksa update...", "Checking for updates..."),
        ["PatchDownloading"] = ("Mengunduh update {0}...", "Downloading update {0}..."),
        ["PatchFailed"] = ("Gagal memeriksa update", "Patch check failed"),
        ["PatchNoDiskSpace"] = ("Ruang disk tidak cukup", "Not enough disk space"),

        ["ReadyPreparing"] = ("●  MEMPERSIAPKAN...", "●  PREPARING..."),
        ["ReadyGood"] = ("●  SIAP DIMAINKAN", "●  GAME READY TO PLAY"),
        ["ReadyFailed"] = ("●  UPDATE GAGAL", "●  UPDATE FAILED"),
        ["ReadyDiskLow"] = ("●  RUANG DISK KURANG", "●  DISK SPACE LOW"),

        ["ReadySubPreparing"] = ("Memeriksa update sebelum kamu bisa main.", "Checking for updates before you can play."),
        ["ReadySubGood"] = ("Semua sistem berjalan normal.", "All systems are operational."),
        ["ReadySubFailed"] = ("Tidak bisa memverifikasi file game. Coba Check Server, lalu buka ulang launcher.", "Could not verify game files. Try Check Server, then reopen the launcher."),
        ["ReadySubDiskLow"] = ("Ruang disk kosong tidak cukup untuk mengunduh update.", "Not enough free disk space to download the update."),

        ["StartChecking"] = ("MEMERIKSA UPDATE...", "CHECKING FOR UPDATES..."),
        ["StartResuming"] = ("MELANJUTKAN SESI...", "RESUMING SESSION..."),
        ["StartSigningIn"] = ("MASUK...", "SIGNING IN..."),
        ["StartLaunching"] = ("MEMBUKA GAME...", "LAUNCHING..."),
        ["StartReady"] = ("MULAI MAIN   ▶", "START GAME   ▶"),
        ["StartNoDiskSpace"] = ("RUANG DISK TIDAK CUKUP", "NOT ENOUGH DISK SPACE"),
        ["StartUpdateRequired"] = ("PERLU UPDATE", "UPDATE REQUIRED"),

        ["NewsLoading"] = ("Memuat berita terbaru...", "Loading latest news..."),
        ["NewsLoadFailed"] = ("Gagal memuat berita. Cek koneksimu.", "Could not load news. Check your connection."),

        ["GameAlreadyRunning"] = ("Game sudah berjalan — memindahkan window ke depan.", "Game is already running — bringing its window to front."),

        ["VersionLatest"] = ("Versi Terbaru", "Latest Version"),
        ["VersionNewAvailable"] = ("Versi baru tersedia: {0}", "New version available: {0}"),
        ["UpdateAvailableLabel"] = ("Update tersedia — klik untuk unduh", "Update available — click to download"),
        ["UpdateDownloading"] = ("Mengunduh update...", "Downloading update..."),
    };

    public static string T(string key, params object[] args)
    {
        if (!Strings.TryGetValue(key, out var pair))
            return key; // fallback: tampilkan key mentah supaya kelihatan kalau ada yang belum diterjemahkan

        string template = CurrentLanguage == "en" ? pair.En : pair.Id;
        return args.Length > 0 ? string.Format(template, args) : template;
    }
}
