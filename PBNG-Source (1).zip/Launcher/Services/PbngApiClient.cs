using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
namespace NGPB.Launcher.Services;

public sealed class PbngApiClient {
    private readonly HttpClient _http;
    public PbngApiClient(string baseUrl){ _http=new HttpClient{BaseAddress=new Uri(baseUrl.TrimEnd('/')+"/")}; }

    public async Task<bool> HealthAsync(CancellationToken ct=default){ try { var r=await _http.GetAsync("api/health",ct); return r.IsSuccessStatusCode; } catch{return false;} }

    // Sekarang mengembalikan pesan error yang jelas (termasuk kalau kena
    // rate-limit setelah 5x gagal login) alih-alih cuma null generik.
    public async Task<LoginOutcome> LoginAsync(string username,string password,CancellationToken ct=default){
        try {
            var r = await _http.PostAsJsonAsync("api/auth/login", new { username, password }, ct);
            if (r.IsSuccessStatusCode)
            {
                var body = await r.Content.ReadFromJsonAsync<LoginResponse>(cancellationToken: ct);
                return new LoginOutcome(true, body, null, false);
            }

            if (r.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
            {
                var errBody = await SafeReadErrorAsync(r, ct);
                return new LoginOutcome(false, null, errBody ?? "Too many failed attempts. Please wait before trying again.", true);
            }

            return new LoginOutcome(false, null, "Invalid username or password.", false);
        }
        catch (Exception ex)
        {
            return new LoginOutcome(false, null, "Could not reach server: " + ex.Message, false);
        }
    }

    public async Task<RegisterOutcome> RegisterAsync(string username,string password,string email,CancellationToken ct=default){
        try {
            var r = await _http.PostAsJsonAsync("api/auth/register", new { username, password, email }, ct);
            if (r.IsSuccessStatusCode) return new RegisterOutcome(true, null);

            string? message = await SafeReadErrorAsync(r, ct);
            return new RegisterOutcome(false, message ?? $"Registration failed ({(int)r.StatusCode}).");
        }
        catch (Exception ex)
        {
            return new RegisterOutcome(false, "Could not reach server: " + ex.Message);
        }
    }

    private static async Task<string?> SafeReadErrorAsync(HttpResponseMessage r, CancellationToken ct)
    {
        try
        {
            var doc = await r.Content.ReadFromJsonAsync<Dictionary<string, string>>(cancellationToken: ct);
            return doc is not null && doc.TryGetValue("error", out var msg) ? msg : null;
        }
        catch { return null; }
    }

    public async Task<PatchManifest?> GetManifestAsync(CancellationToken ct=default){ return await _http.GetFromJsonAsync<PatchManifest>("api/patch/manifest",ct); }
    public async Task<OnlineStats?> GetOnlineStatsAsync(CancellationToken ct=default){ try { return await _http.GetFromJsonAsync<OnlineStats>("api/stats/online",ct); } catch { return null; } }
    public async Task<List<NewsArticle>?> GetNewsAsync(CancellationToken ct=default){ try { return await _http.GetFromJsonAsync<List<NewsArticle>>("api/news",ct); } catch { return null; } }
    public async Task<LauncherVersionInfo?> GetLauncherVersionAsync(CancellationToken ct=default){ try { return await _http.GetFromJsonAsync<LauncherVersionInfo>("api/launcher/version",ct); } catch { return null; } }

    public async Task<bool> ValidateTokenAsync(string token,CancellationToken ct=default){
        try {
            using var req=new HttpRequestMessage(HttpMethod.Get,"api/auth/validate");
            req.Headers.Authorization=new AuthenticationHeaderValue("Bearer",token);
            var r=await _http.SendAsync(req,ct);
            return r.IsSuccessStatusCode;
        } catch { return false; }
    }

    /// <summary>
    /// Download + verifikasi SHA-256. Sekarang mendukung RESUME: kalau file
    /// ".download" sebelumnya sudah ada sebagian (misal koneksi putus di
    /// tengah jalan), lanjut dari byte terakhir lewat HTTP Range request,
    /// bukan mulai dari 0 lagi.
    /// </summary>
    public async Task DownloadAndVerifyAsync(PatchFile file,string destination,IProgress<double>? progress=null,CancellationToken ct=default){
        Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
        var temp = destination + ".download";

        long existingBytes = File.Exists(temp) ? new FileInfo(temp).Length : 0;
        if (existingBytes >= file.Size) existingBytes = 0; // file lama korup/lebih besar dari seharusnya, mulai ulang

        using var request = new HttpRequestMessage(HttpMethod.Get, file.Url);
        if (existingBytes > 0)
            request.Headers.Range = new System.Net.Http.Headers.RangeHeaderValue(existingBytes, null);

        using var response = await _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);

        bool serverHonoredRange = response.StatusCode == System.Net.HttpStatusCode.PartialContent;
        if (!serverHonoredRange) existingBytes = 0; // server tidak mendukung resume, mulai dari 0

        response.EnsureSuccessStatusCode();

        var fileMode = existingBytes > 0 ? FileMode.Append : FileMode.Create;
        await using var input = await response.Content.ReadAsStreamAsync(ct);
        await using var output = new FileStream(temp, fileMode, FileAccess.Write, FileShare.None);

        long total = file.Size;
        long read = existingBytes;
        var buffer = new byte[1024 * 128];
        int n;
        while ((n = await input.ReadAsync(buffer, ct)) > 0)
        {
            await output.WriteAsync(buffer.AsMemory(0, n), ct);
            read += n;
            progress?.Report(total > 0 ? read * 100d / total : 0);
        }
        await output.FlushAsync(ct);
        output.Close();

        using var sha = SHA256.Create();
        await using var check = File.OpenRead(temp);
        var hash = Convert.ToHexString(await sha.ComputeHashAsync(check, ct));
        if (!hash.Equals(file.Sha256, StringComparison.OrdinalIgnoreCase))
        {
            File.Delete(temp); // hash tidak cocok -> file rusak/tidak lengkap, hapus supaya coba dari 0 lagi lain kali
            throw new InvalidDataException("PATCH_HASH_MISMATCH");
        }
        File.Move(temp, destination, true);
    }

    /// <summary>Cek ruang disk kosong di drive tempat folder Game/ berada.</summary>
    public static long GetAvailableFreeBytes(string path)
    {
        try
        {
            string root = Path.GetPathRoot(Path.GetFullPath(path)) ?? "C:\\";
            return new DriveInfo(root).AvailableFreeSpace;
        }
        catch { return long.MaxValue; } // kalau gagal deteksi, jangan blokir pemain — anggap cukup
    }

    public record LoginResponse(string AccessToken,string Username,int ExpiresIn);
    public record LoginOutcome(bool Success, LoginResponse? Response, string? ErrorMessage, bool RateLimited);
    public record RegisterOutcome(bool Success, string? ErrorMessage);
    public record PatchManifest(string Product,string Channel,string Version,List<PatchFile> Files);
    public record PatchFile(string Path,long Size,string Sha256,string Url);
    public record OnlineStats(int Online,int PeakToday);
    public record NewsArticle(string Tag,string Title,string Description,string Date,string ThumbnailKey);
    public record LauncherVersionInfo(string LatestVersion,string DownloadUrl,string Notes);
}
