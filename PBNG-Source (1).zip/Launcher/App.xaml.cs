using System;
using System.Threading;
using System.Windows;

namespace NGPB.Launcher;

public partial class App : System.Windows.Application
{
    // Mutex bernama global — kalau launcher sudah jalan (proses lain pegang
    // mutex ini), instance baru langsung keluar tanpa buka window kedua.
    private static Mutex? _singleInstanceMutex;

    protected override void OnStartup(StartupEventArgs e)
    {
        const string mutexName = "Global\\PBNG-NGPB-Launcher-SingleInstance-18E2C6F0";
        _singleInstanceMutex = new Mutex(initiallyOwned: true, name: mutexName, out bool createdNew);

        if (!createdNew)
        {
            MessageBox.Show(
                "PBNG Launcher is already running.\nCheck your taskbar or system tray.",
                "PBNG Launcher", MessageBoxButton.OK, MessageBoxImage.Information);
            Shutdown();
            return;
        }

        base.OnStartup(e);
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _singleInstanceMutex?.ReleaseMutex();
        _singleInstanceMutex?.Dispose();
        base.OnExit(e);
    }
}
