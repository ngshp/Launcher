using System.Windows;
using NGPB.Launcher.Services;

namespace NGPB.Launcher;

public partial class RegisterWindow : Window
{
    private readonly PbngApiClient _api;

    public string Username => UsernameBox.Text.Trim();
    public string Password => PasswordBox.Password;

    public RegisterWindow(PbngApiClient api)
    {
        InitializeComponent();
        _api = api;
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }

    private async void RegisterButton_Click(object sender, RoutedEventArgs e)
    {
        ErrorText.Visibility = Visibility.Collapsed;

        if (UsernameBox.Text.Trim().Length < 3)
        {
            ShowError("Username must be at least 3 characters.");
            return;
        }
        if (!EmailBox.Text.Contains('@'))
        {
            ShowError("Please enter a valid email address.");
            return;
        }
        if (PasswordBox.Password.Length < 8)
        {
            ShowError("Password must be at least 8 characters.");
            return;
        }
        if (PasswordBox.Password != ConfirmPasswordBox.Password)
        {
            ShowError("Passwords do not match.");
            return;
        }

        RegisterButton.IsEnabled = false;
        RegisterButton.Content = "CREATING...";

        var result = await _api.RegisterAsync(UsernameBox.Text.Trim(), PasswordBox.Password, EmailBox.Text.Trim());

        if (result.Success)
        {
            MessageBox.Show("Account created! You can now log in.", "PBNG", MessageBoxButton.OK, MessageBoxImage.Information);
            DialogResult = true;
        }
        else
        {
            ShowError(result.ErrorMessage ?? "Registration failed. Please try again.");
            RegisterButton.IsEnabled = true;
            RegisterButton.Content = "REGISTER";
        }
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e) => DialogResult = false;
}
