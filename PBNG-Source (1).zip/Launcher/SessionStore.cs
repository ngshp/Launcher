using System;
using System.IO;
using System.Runtime.Versioning;
using System.Security.Cryptography;
using System.Text;

namespace NGPB.Launcher;

/// <summary>
/// Menyimpan launch ticket (token login) di disk supaya pemain tidak perlu
/// login ulang setiap membuka launcher, kalau mereka centang "Remember me".
///
/// Token dienkripsi pakai Windows Data Protection API (DPAPI), terikat ke
/// akun Windows pemain yang login saat ini — bukan disimpan sebagai teks
/// polos, dan tidak bisa dibaca kalau file-nya disalin ke komputer/akun lain.
/// </summary>
[SupportedOSPlatform("windows")]
public static class SessionStore
{
    private static readonly string FilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "PBNG", "session.dat");

    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("PBNG-Launcher-Session-v1");

    public static void Save(string token)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            byte[] plain = Encoding.UTF8.GetBytes(token);
            byte[] encrypted = ProtectedData.Protect(plain, Entropy, DataProtectionScope.CurrentUser);
            File.WriteAllBytes(FilePath, encrypted);
        }
        catch
        {
            // Gagal simpan bukan error fatal — pemain cukup login manual lagi.
        }
    }

    public static string? Load()
    {
        try
        {
            if (!File.Exists(FilePath)) return null;
            byte[] encrypted = File.ReadAllBytes(FilePath);
            byte[] plain = ProtectedData.Unprotect(encrypted, Entropy, DataProtectionScope.CurrentUser);
            return Encoding.UTF8.GetString(plain);
        }
        catch
        {
            return null;
        }
    }

    public static void Clear()
    {
        try { if (File.Exists(FilePath)) File.Delete(FilePath); }
        catch { /* abaikan */ }
    }
}
