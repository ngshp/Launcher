using System;
using System.IO;
using System.Text.Json;

namespace NGPB.Launcher;

/// <summary>
/// Pengaturan lokal launcher yang TIDAK sensitif (beda dengan SessionStore
/// yang menyimpan token terenkripsi). Disimpan sebagai JSON polos karena
/// isinya cuma preferensi UI, bukan kredensial.
/// </summary>
public sealed class LauncherSettings
{
    public bool MinimizeToTray { get; set; } = true;
    public bool EulaAccepted { get; set; } = false;
    public string Language { get; set; } = "id"; // "id" atau "en"

    private static readonly string FilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "PBNG", "settings.json");

    public static LauncherSettings Load()
    {
        try
        {
            if (!File.Exists(FilePath)) return new LauncherSettings();
            var json = File.ReadAllText(FilePath);
            return JsonSerializer.Deserialize<LauncherSettings>(json,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new LauncherSettings();
        }
        catch
        {
            return new LauncherSettings();
        }
    }

    public void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(this));
        }
        catch { /* gagal simpan setting bukan error fatal */ }
    }
}
