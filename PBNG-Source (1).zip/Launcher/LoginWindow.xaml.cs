using System.Windows;
using NGPB.Launcher.Services;

namespace NGPB.Launcher;

public partial class LoginWindow : Window
{
    private readonly PbngApiClient _api;

    public string Username => UsernameBox.Text.Trim();
    public string Password => PasswordBox.Password;
    public bool RememberMe => RememberMeBox.IsChecked == true;

    public LoginWindow(PbngApiClient api)
    {
        InitializeComponent();
        _api = api;
    }

    public void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }

    private void LoginButton_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password))
        {
            ShowError("Username and password are required.");
            return;
        }
        DialogResult = true;
    }

    private void CancelButton_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
    }

    private void CreateAccountLink_Click(object sender, RoutedEventArgs e)
    {
        var register = new RegisterWindow(_api) { Owner = this };
        if (register.ShowDialog() == true)
        {
            UsernameBox.Text = register.Username;
            PasswordBox.Password = register.Password;
        }
    }
}
