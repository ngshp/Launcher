using System.Windows;

namespace NGPB.Launcher;

public partial class EulaWindow : Window
{
    public EulaWindow()
    {
        InitializeComponent();
    }

    private void AgreeButton_Click(object sender, RoutedEventArgs e) => DialogResult = true;
    private void DeclineButton_Click(object sender, RoutedEventArgs e) => DialogResult = false;
}
