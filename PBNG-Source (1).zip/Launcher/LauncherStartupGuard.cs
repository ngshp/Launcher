using System;
using System.IO;
namespace NGPB.Launcher;
public static class LauncherStartupGuard
{
    public static bool ValidateClientPath(out string message)
    {
        string path = Path.Combine(AppContext.BaseDirectory, "Game", "ngpb-client.exe");
        if (!File.Exists(path)) { message = "GAME CLIENT NOT FOUND"; return false; }
        message = "SECURITY PATH CHECK OK";
        return true;
    }
}
