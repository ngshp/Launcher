// Project ini memakai UseWPF=true DAN UseWindowsForms=true sekaligus
// (WinForms dipakai khusus untuk NotifyIcon/system tray di TrayIconManager.cs).
// Efek sampingnya: beberapa nama kelas ada di KEDUA namespace
// (System.Windows milik WPF, System.Windows.Forms milik WinForms) —
// kalau dipakai tanpa qualifier, compiler bingung mau pakai yang mana.
//
// Daripada menulis "System.Windows.Xxx" panjang-panjang di puluhan tempat,
// alias global di sini berlaku untuk SELURUH file di project (fitur C# 10+),
// jadi cukup didefinisikan sekali saja.
global using Application = System.Windows.Application;
global using MessageBox = System.Windows.MessageBox;
