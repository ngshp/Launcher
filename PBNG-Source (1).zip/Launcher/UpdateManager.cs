using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;

namespace NGPB.Launcher;

/// <summary>
/// Sebelumnya kalau ada versi baru, launcher cuma kasih teks "Update
/// available" + link untuk didownload manual oleh pemain. Sekarang bisa
/// benar-benar download exe baru dan restart otomatis.
///
/// Karena exe yang sedang berjalan tidak bisa menimpa dirinya sendiri di
/// Windows (file terkunci selama proses masih hidup), triknya: tulis
/// exe baru ke file sementara, buat script .bat kecil yang menunggu
/// proses lama keluar lalu menggantikan file lama dengan yang baru dan
/// menjalankannya lagi — baru setelah itu proses launcher yang sekarang
/// (lama) keluar.
/// </summary>
public static class UpdateManager
{
    public static async Task<bool> DownloadAndApplyUpdateAsync(string downloadUrl, IProgress<double>? progress = null)
    {
        try
        {
            string currentExe = Process.GetCurrentProcess().MainModule!.FileName!;
            string tempNewExe = currentExe + ".update";

            using var http = new HttpClient { Timeout = TimeSpan.FromMinutes(10) };
            using var response = await http.GetAsync(downloadUrl, HttpCompletionOption.ResponseHeadersRead);
            response.EnsureSuccessStatusCode();

            long total = response.Content.Headers.ContentLength ?? 0;
            long read = 0;
            var buffer = new byte[1024 * 128];

            await using var input = await response.Content.ReadAsStreamAsync();
            await using var output = File.Create(tempNewExe);

            int n;
            while ((n = await input.ReadAsync(buffer)) > 0)
            {
                await output.WriteAsync(buffer.AsMemory(0, n));
                read += n;
                progress?.Report(total > 0 ? read * 100d / total : 0);
            }
            await output.FlushAsync();
            output.Close();

            string script = BuildUpdateScript(currentExe, tempNewExe);
            string scriptPath = Path.Combine(Path.GetTempPath(), $"pbng-update-{Guid.NewGuid():N}.bat");
            await File.WriteAllTextAsync(scriptPath, script);

            Process.Start(new ProcessStartInfo
            {
                FileName = scriptPath,
                UseShellExecute = true,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,
            });

            // Proses launcher yang sekarang harus keluar supaya script bisa
            // menimpa exe-nya. Dipanggil oleh pemanggil (MainWindow) lewat
            // Application.Current.Shutdown() setelah method ini return true.
            return true;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Update failed: " + ex.Message, "PBNG Launcher", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }
    }

    private static string BuildUpdateScript(string currentExe, string tempNewExe)
    {
        // "ping -n 3" dipakai sebagai delay sederhana (~2 detik) menunggu
        // proses lama benar-benar keluar sebelum file di-overwrite,
        // tanpa perlu tool eksternal tambahan.
        return $"""
            @echo off
            ping -n 3 127.0.0.1 > nul
            move /y "{tempNewExe}" "{currentExe}"
            start "" "{currentExe}"
            del "%~f0"
            """;
    }
}
