using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace NGPB.Launcher;

public partial class SettingsWindow : Window
{
    private readonly LauncherSettings _settings;

    public SettingsWindow(LauncherSettings settings)
    {
        InitializeComponent();
        _settings = settings;

        MinimizeToTrayBox.IsChecked = _settings.MinimizeToTray;
        LanguageBox.SelectedItem = LanguageBox.Items
            .OfType<ComboBoxItem>()
            .FirstOrDefault(i => (string)i.Tag == _settings.Language) ?? LanguageBox.Items[0];
    }

    private void ForgetSessionButton_Click(object sender, RoutedEventArgs e)
    {
        SessionStore.Clear();
        InfoText.Text = "Saved session cleared. You'll need to log in next time.";
        InfoText.Visibility = Visibility.Visible;
    }

    private void SaveButton_Click(object sender, RoutedEventArgs e)
    {
        _settings.MinimizeToTray = MinimizeToTrayBox.IsChecked == true;
        _settings.Language = (LanguageBox.SelectedItem as ComboBoxItem)?.Tag as string ?? "id";
        _settings.Save();
        Loc.CurrentLanguage = _settings.Language;
        DialogResult = true;
    }
}
