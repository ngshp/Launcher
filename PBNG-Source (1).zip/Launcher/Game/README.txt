Place your authorized ngpb-client.exe here. The launcher START GAME button launches this exact path.
