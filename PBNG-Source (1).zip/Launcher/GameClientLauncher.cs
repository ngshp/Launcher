using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace NGPB.Launcher;

public sealed class GameClientLauncher
{
    public enum LaunchResult { Started, AlreadyRunning }

    public LaunchResult Start(string launchTicket, string gateway = "http://127.0.0.1:5182")
    {
        if (string.IsNullOrWhiteSpace(launchTicket))
            throw new ArgumentException("Launch ticket is required.", nameof(launchTicket));

        // Kalau ngpb-client.exe sudah jalan (pemain klik Start Game dua kali,
        // atau game masih terbuka dari sesi sebelumnya), jangan buka instance
        // kedua — cukup bawa ke depan (fokuskan) window yang sudah ada.
        var running = Process.GetProcessesByName("ngpb-client").FirstOrDefault();
        if (running is not null)
        {
            BringToFront(running);
            return LaunchResult.AlreadyRunning;
        }

        string gameDir = Path.Combine(AppContext.BaseDirectory, "Game");
        string exe = Path.Combine(gameDir, "ngpb-client.exe");
        if (!File.Exists(exe)) throw new FileNotFoundException("PBNG game client was not found.", exe);

        var psi = new ProcessStartInfo { FileName = exe, WorkingDirectory = gameDir, UseShellExecute = false };
        psi.Environment["PBNG_LAUNCH_TICKET"] = launchTicket;
        psi.Environment["PBNG_GAME_GATEWAY"] = gateway;

        _ = Process.Start(psi) ?? throw new InvalidOperationException("Unable to start ngpb-client.exe.");
        return LaunchResult.Started;
    }

    private static void BringToFront(Process process)
    {
        try
        {
            IntPtr handle = process.MainWindowHandle;
            if (handle != IntPtr.Zero)
            {
                NativeMethods.ShowWindow(handle, NativeMethods.SW_RESTORE);
                NativeMethods.SetForegroundWindow(handle);
            }
        }
        catch { /* game window belum sepenuhnya siap / handle tidak valid — abaikan */ }
    }

    private static class NativeMethods
    {
        public const int SW_RESTORE = 9;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);
    }
}
