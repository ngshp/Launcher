using System;
using System.Collections.Generic;
using NGPB.Launcher.Services;

namespace NGPB.Launcher;

/// <summary>
/// Membungkus PbngApiClient.NewsArticle (data dari server) supaya bisa
/// di-bind ke ItemsControl di MainWindow.xaml. Gambar thumbnail tetap
/// dibundel lokal di Assets/News (tidak di-download dari server) — hanya
/// teks (tag/judul/deskripsi/tanggal) yang datang dari server, dipetakan
/// lewat ThumbnailKey.
/// </summary>
public sealed class NewsItemViewModel
{
    public string Tag { get; init; } = "";
    public string Title { get; init; } = "";
    public string Description { get; init; } = "";
    public string DisplayDate { get; init; } = "";
    public string ThumbnailPath { get; init; } = "";
    public double TitleFontSize { get; init; } = 24;

    private static readonly Dictionary<string, string> ThumbnailMap = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Outpost"] = "Assets/News/News_Outpost.png",
        ["Weapon"] = "Assets/News/News_Weapon.png",
        ["Event"] = "Assets/News/News_Event.png",
        ["AntiCheat"] = "Assets/News/News_AntiCheat.png",
    };

    // Dipakai kalau server mengirim thumbnailKey yang tidak dikenali
    // launcher versi ini (misalnya launcher belum diupdate).
    private const string FallbackThumbnail = "Assets/News/News_Outpost.png";

    public static NewsItemViewModel FromArticle(PbngApiClient.NewsArticle article)
    {
        string thumbnail = ThumbnailMap.TryGetValue(article.ThumbnailKey, out var path)
            ? path
            : FallbackThumbnail;

        return new NewsItemViewModel
        {
            Tag = article.Tag,
            Title = article.Title,
            Description = article.Description,
            DisplayDate = "▣  " + article.Date,
            ThumbnailPath = thumbnail,
            TitleFontSize = article.Title.Length > 14 ? 20 : 24,
        };
    }
}
