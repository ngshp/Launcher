using System.Windows;
namespace PBNG.SecurityBootstrapper;
public partial class App : Application { }
