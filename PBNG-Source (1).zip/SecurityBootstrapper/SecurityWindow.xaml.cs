using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
namespace PBNG.SecurityBootstrapper;
public partial class SecurityWindow : Window
{
    // Lihat catatan yang sama di GameClient/SecurityGateWindow.xaml.cs:
    // sebelumnya flag ini (_verified) tidak pernah diset balik kalau
    // verifikasi gagal, jadi window ini (WindowStyle="None",
    // ShowInTaskbar="False", tanpa tombol Close) jadi tidak bisa ditutup
    // sama sekali kalau "NG PB Launcher.exe" tidak ditemukan. Sekarang
    // closing hanya diblokir SELAMA proses verifikasi berjalan.
    private bool _checking = true;

    public SecurityWindow()
    {
        InitializeComponent();
        Loaded += async (_, _) => await RunAsync();
        Closing += (_, e) => { if (_checking) e.Cancel = true; };
        KeyDown += (_, e) => { if (e.Key == Key.Escape && !_checking) Close(); };
    }

    private async Task RunAsync()
    {
        try
        {
            await LayerAsync(1, "SECURITY LOADING — LAYER 1", "Initializing secure environment...");
            await LayerAsync(2, "SECURITY VERIFICATION — LAYER 2", "Verifying launcher files and security policy...");

            string launcher = Path.Combine(AppContext.BaseDirectory, "NG PB Launcher.exe");
            if (!File.Exists(launcher))
            {
                StatusText.Text = "LAUNCHER NOT FOUND";
                Footer.Text = "Place NG PB Launcher.exe beside this bootstrapper. (Press Esc or click to close)";
                return;
            }

            var psi = new ProcessStartInfo { FileName = launcher, WorkingDirectory = AppContext.BaseDirectory, UseShellExecute = false };
            Process.Start(psi);
            Close();
        }
        catch
        {
            StatusText.Text = "SECURITY VERIFICATION FAILED";
            Footer.Text = "Launcher startup was blocked. (Press Esc or click to close)";
        }
        finally
        {
            _checking = false;
        }
    }

    private async Task LayerAsync(int layer, string title, string message)
    {
        LayerTitle.Text = title;
        StatusText.Text = message;
        for (int i = 0; i <= 100; i += 5)
        {
            Progress.Value = i;
            await Task.Delay(25);
            Dispatcher.Invoke(DispatcherPriority.Background, new Action(() => { }));
        }
    }

    private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (!_checking) Close();
    }
}
