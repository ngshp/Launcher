using System.Security.Cryptography;
using System.Text.Json;
using PBNG.AuthPatchServer.Models;
using PBNG.AuthPatchServer.Services;
using Serilog;

// -----------------------------------------------------------------------
// Logging: sebelumnya server ini tidak mencatat apa pun ke file — kalau
// ada masalah di production, tidak ada jejak untuk didiagnosis. Sekarang
// pakai Serilog, log harian ke Logs/server-YYYYMMDD.log, plus tetap
// tampil di konsol untuk saat development.
// -----------------------------------------------------------------------
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console()
    .WriteTo.File(
        Path.Combine(AppContext.BaseDirectory, "Logs", "server-.log"),
        rollingInterval: RollingInterval.Day,
        retainedFileCountLimit: 14)
    .MinimumLevel.Information()
    .CreateLogger();

var builder = WebApplication.CreateBuilder(args);
builder.Host.UseSerilog();

builder.Services.AddSingleton<AccountStore>();
builder.Services.AddSingleton<TokenStore>();
builder.Services.AddSingleton<ManifestService>();
builder.Services.AddSingleton<OnlineStatsService>();
builder.Services.AddSingleton<NewsService>();
builder.Services.AddSingleton<LoginRateLimiter>();
var app = builder.Build();

// -----------------------------------------------------------------------
// HTTPS: paksa redirect ke HTTPS kalau server diakses lewat HTTP.
// CATATAN PENTING: ini hanya redirect logic-nya. Supaya benar-benar
// jalan, Kestrel perlu dikonfigurasi dengan sertifikat TLS asli (lihat
// appsettings.json -> bagian Kestrel:Endpoints:Https, dan README untuk
// cara pasang sertifikat Let's Encrypt/dari CA). Tanpa sertifikat asli
// terpasang, baris ini tidak berbahaya (development tetap jalan di
// http://127.0.0.1 seperti biasa) tapi juga tidak memberi proteksi nyata.
// -----------------------------------------------------------------------
if (!app.Environment.IsDevelopment())
{
    app.UseHttpsRedirection();
}

app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/health", () => Results.Ok(new { service="PBNG Auth + Patch Server", version="18.2.0", status="ONLINE", utc=DateTime.UtcNow }));

app.MapPost("/api/auth/register", async (RegisterRequest req, AccountStore accounts, ILogger<Program> logger) => {
    var result = await accounts.RegisterAsync(req.Username, req.Password, req.Email);
    return result switch
    {
        AccountStore.RegisterResult.Success => Results.Ok(new { success = true }),
        AccountStore.RegisterResult.UsernameTaken => Results.Conflict(new { error = "Username already taken." }),
        AccountStore.RegisterResult.InvalidInput => Results.BadRequest(new {
            error = "Username must be at least 3 characters, password at least 8 characters, and email must be valid."
        }),
        _ => Results.Problem("Unknown error.")
    };
});

app.MapPost("/api/auth/login", async (LoginRequest req, AccountStore accounts, TokenStore tokens,
    LoginRateLimiter rateLimiter, HttpContext ctx, ILogger<Program> logger) => {

    string ip = ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown";

    if (rateLimiter.IsLockedOut(req.Username, ip, out var retryAfter))
    {
        logger.LogWarning("Login blocked (rate limited): user={User} ip={Ip}", req.Username, ip);
        ctx.Response.Headers.RetryAfter = ((int)retryAfter.TotalSeconds).ToString();
        return Results.Json(new { error = $"Too many failed attempts. Try again in {(int)retryAfter.TotalMinutes + 1} minute(s)." },
            statusCode: StatusCodes.Status429TooManyRequests);
    }

    var account = await accounts.ValidateAsync(req.Username, req.Password);
    if (account is null)
    {
        rateLimiter.RecordFailure(req.Username, ip);
        logger.LogInformation("Failed login attempt: user={User} ip={Ip}", req.Username, ip);
        return Results.Unauthorized();
    }

    rateLimiter.RecordSuccess(req.Username, ip);
    var token = tokens.Create(account.Username);
    logger.LogInformation("Successful login: user={User} ip={Ip}", account.Username, ip);
    return Results.Ok(new { accessToken=token, username=account.Username, expiresIn=3600 });
});

app.MapGet("/api/auth/validate", (HttpRequest request, TokenStore tokens) => {
    var auth = request.Headers.Authorization.ToString();
    if (!auth.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)) return Results.Unauthorized();
    var user = tokens.Validate(auth[7..]);
    return user is null ? Results.Unauthorized() : Results.Ok(new { username=user, valid=true });
});

// Dipakai oleh ngpb-client.exe (GameClient) untuk verifikasi launch ticket
// sebelum menampilkan jendela game. Kontrak endpoint ini sebelumnya hanya
// didokumentasikan di Server/GameHandshakeEndpoint.cs — sekarang diimplementasikan.
app.MapGet("/api/game/handshake", (HttpRequest request, TokenStore tokens) => {
    var auth = request.Headers.Authorization.ToString();
    if (!auth.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)) return Results.Unauthorized();
    var user = tokens.Validate(auth[7..]);
    if (user is null) return Results.Unauthorized();
    return Results.Ok(new { service = "PBNG Game Gateway", status = "OK", user, utc = DateTime.UtcNow });
});

app.MapGet("/api/stats/online", (OnlineStatsService stats) => {
    var (online, peakToday) = stats.GetStats();
    return Results.Ok(new { online, peakToday });
});

app.MapGet("/api/news", (NewsService news) => Results.Ok(news.Load()));

// Versi launcher DEPLOYED di server ini. Bandingkan dengan versi build
// launcher (LauncherAppVersion di MainWindow.xaml.cs) untuk kasih tahu
// pemain kalau launcher-nya sendiri (bukan game) perlu diupdate.
app.MapGet("/api/launcher/version", () => Results.Ok(
    new LauncherVersionInfo("18.2.0", "https://example.com/download/pbng-launcher", "No changes yet.")
));

app.MapGet("/api/patch/manifest", (ManifestService manifests) => Results.Ok(manifests.Load()));
app.MapGet("/api/patch/files/{**path}", (string path, IWebHostEnvironment env) => {
    var full = Path.GetFullPath(Path.Combine(env.ContentRootPath, "PatchFiles", path));
    var root = Path.GetFullPath(Path.Combine(env.ContentRootPath, "PatchFiles")) + Path.DirectorySeparatorChar;
    if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase) || !File.Exists(full)) return Results.NotFound();
    return Results.File(full, "application/octet-stream", enableRangeProcessing:true);
});

app.Run();
