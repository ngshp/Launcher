namespace PBNG.AuthPatchServer.Models;
public record LoginRequest(string Username, string Password);
public record RegisterRequest(string Username, string Password, string Email);
public record AccountRecord(string Username, byte[] Salt, byte[] PasswordHash);
public record PatchManifest(string Product, string Channel, string Version, List<PatchFile> Files);
public record PatchFile(string Path, long Size, string Sha256, string Url);
public record NewsArticle(string Tag, string Title, string Description, string Date, string ThumbnailKey);
public record LauncherVersionInfo(string LatestVersion, string DownloadUrl, string Notes);
