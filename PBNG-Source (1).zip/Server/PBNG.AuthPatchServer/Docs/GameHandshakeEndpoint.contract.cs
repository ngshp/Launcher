// Contract for the PBNG gateway.
// GET /api/game/handshake
// Authorization: Bearer <short-lived launch ticket>
// Production server must validate signature, expiry, account/session binding,
// client version, server/channel and replay protection before accepting the client.
