using System.Collections.Concurrent;
using System.Security.Cryptography;
namespace PBNG.AuthPatchServer.Services;
public sealed class TokenStore {
    private readonly ConcurrentDictionary<string,(string User,DateTime Exp)> _tokens=new();
    public string Create(string user){ var token=Convert.ToBase64String(RandomNumberGenerator.GetBytes(32)); _tokens[token]=(user,DateTime.UtcNow.AddHours(1)); return token; }
    public string? Validate(string token){ if(_tokens.TryGetValue(token,out var x)&&x.Exp>DateTime.UtcNow)return x.User; _tokens.TryRemove(token,out _); return null; }
    public int ActiveCount { get { CleanExpired(); return _tokens.Count; } }
    private void CleanExpired(){ var now=DateTime.UtcNow; foreach(var kv in _tokens){ if(kv.Value.Exp<=now) _tokens.TryRemove(kv.Key,out _); } }
}
