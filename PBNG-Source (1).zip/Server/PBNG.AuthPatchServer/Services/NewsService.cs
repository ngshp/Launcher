using System.Text.Json;
using PBNG.AuthPatchServer.Models;

namespace PBNG.AuthPatchServer.Services;

/// <summary>
/// Sebelumnya 4 berita ini hardcoded permanen di MainWindow.xaml launcher —
/// artinya update judul/tanggal/isi berita perlu build ulang aplikasi.
/// Sekarang dipindah ke sini supaya bisa diubah cukup dengan mengedit
/// news.json di server, tanpa perlu build ulang launcher.
/// </summary>
public sealed class NewsService
{
    private readonly string _path;

    public NewsService(IWebHostEnvironment env)
    {
        _path = Path.Combine(env.ContentRootPath, "Content", "news.json");
    }

    public List<NewsArticle> Load()
    {
        if (!File.Exists(_path)) return new List<NewsArticle>();
        var json = File.ReadAllText(_path);
        return JsonSerializer.Deserialize<List<NewsArticle>>(json,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new List<NewsArticle>();
    }
}
