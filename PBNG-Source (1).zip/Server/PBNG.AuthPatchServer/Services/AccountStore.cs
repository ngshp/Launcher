using System.Security.Cryptography;
using Microsoft.Data.Sqlite;
using PBNG.AuthPatchServer.Models;

namespace PBNG.AuthPatchServer.Services;

/// <summary>
/// Sebelumnya akun disimpan sebagai satu file JSON polos (accounts.json)
/// yang dibaca-tulis ulang setiap kali — tidak aman untuk banyak pemain
/// mendaftar/login bersamaan (race condition saat dua request menulis
/// file yang sama di waktu hampir bersamaan bisa saling menimpa data).
///
/// Sekarang pakai SQLite: satu file database (Data/pbng.db) dengan
/// transaksi yang aman untuk akses bersamaan, dan mendukung Register()
/// yang sebelumnya tidak ada sama sekali (dulu akun cuma bisa dibuat
/// lewat 1 akun demo yang di-seed otomatis).
/// </summary>
public sealed class AccountStore
{
    private readonly string _connectionString;

    public AccountStore()
    {
        string dataDir = Path.Combine(AppContext.BaseDirectory, "Data");
        Directory.CreateDirectory(dataDir);
        string dbPath = Path.Combine(dataDir, "pbng.db");
        _connectionString = $"Data Source={dbPath}";

        using var conn = new SqliteConnection(_connectionString);
        conn.Open();
        using var createCmd = conn.CreateCommand();
        createCmd.CommandText = """
            CREATE TABLE IF NOT EXISTS accounts (
                username   TEXT PRIMARY KEY,
                email      TEXT,
                salt       BLOB NOT NULL,
                hash       BLOB NOT NULL,
                created_at TEXT NOT NULL
            );
        """;
        createCmd.ExecuteNonQuery();

        SeedDemoAccountIfEmpty(conn);
    }

    private static void SeedDemoAccountIfEmpty(SqliteConnection conn)
    {
        using var countCmd = conn.CreateCommand();
        countCmd.CommandText = "SELECT COUNT(*) FROM accounts;";
        long count = (long)countCmd.ExecuteScalar()!;
        if (count > 0) return;

        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Hash("ChangeMe123!", salt);

        using var insertCmd = conn.CreateCommand();
        insertCmd.CommandText = """
            INSERT INTO accounts (username, email, salt, hash, created_at)
            VALUES ('test', 'test@example.com', $salt, $hash, $createdAt);
        """;
        insertCmd.Parameters.AddWithValue("$salt", salt);
        insertCmd.Parameters.AddWithValue("$hash", hash);
        insertCmd.Parameters.AddWithValue("$createdAt", DateTime.UtcNow.ToString("O"));
        insertCmd.ExecuteNonQuery();
    }

    private static byte[] Hash(string password, byte[] salt) =>
        Rfc2898DeriveBytes.Pbkdf2(password, salt, 150_000, HashAlgorithmName.SHA256, 32);

    public enum RegisterResult { Success, UsernameTaken, InvalidInput }

    public async Task<RegisterResult> RegisterAsync(string username, string password, string email)
    {
        username = username.Trim();
        if (username.Length < 3 || password.Length < 8 || !email.Contains('@'))
            return RegisterResult.InvalidInput;

        using var conn = new SqliteConnection(_connectionString);
        await conn.OpenAsync();

        using var checkCmd = conn.CreateCommand();
        checkCmd.CommandText = "SELECT COUNT(*) FROM accounts WHERE username = $u COLLATE NOCASE;";
        checkCmd.Parameters.AddWithValue("$u", username);
        long existing = (long)(await checkCmd.ExecuteScalarAsync())!;
        if (existing > 0) return RegisterResult.UsernameTaken;

        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Hash(password, salt);

        using var insertCmd = conn.CreateCommand();
        insertCmd.CommandText = """
            INSERT INTO accounts (username, email, salt, hash, created_at)
            VALUES ($u, $e, $salt, $hash, $createdAt);
        """;
        insertCmd.Parameters.AddWithValue("$u", username);
        insertCmd.Parameters.AddWithValue("$e", email);
        insertCmd.Parameters.AddWithValue("$salt", salt);
        insertCmd.Parameters.AddWithValue("$hash", hash);
        insertCmd.Parameters.AddWithValue("$createdAt", DateTime.UtcNow.ToString("O"));
        await insertCmd.ExecuteNonQueryAsync();

        return RegisterResult.Success;
    }

    public async Task<AccountRecord?> ValidateAsync(string username, string password)
    {
        using var conn = new SqliteConnection(_connectionString);
        await conn.OpenAsync();

        using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT username, salt, hash FROM accounts WHERE username = $u COLLATE NOCASE;";
        cmd.Parameters.AddWithValue("$u", username);

        using var reader = await cmd.ExecuteReaderAsync();
        if (!await reader.ReadAsync()) return null;

        string storedUsername = reader.GetString(0);
        byte[] salt = (byte[])reader["salt"];
        byte[] hash = (byte[])reader["hash"];

        var computed = Hash(password, salt);
        return CryptographicOperations.FixedTimeEquals(computed, hash)
            ? new AccountRecord(storedUsername, salt, hash)
            : null;
    }
}
