namespace PBNG.AuthPatchServer.Services;

/// <summary>
/// Mendekati jumlah "player online" dari jumlah launch-ticket/token yang
/// sedang aktif. Ini perkiraan sederhana (bukan tracking sesi in-game
/// sungguhan) — cukup untuk menggantikan angka simulasi di launcher
/// dengan angka yang benar-benar berasal dari server.
/// </summary>
public sealed class OnlineStatsService
{
    private readonly TokenStore _tokens;
    private int _peakToday;

    public OnlineStatsService(TokenStore tokens) => _tokens = tokens;

    public (int online, int peakToday) GetStats()
    {
        int online = _tokens.ActiveCount;
        if (online > _peakToday) _peakToday = online;
        return (online, _peakToday);
    }
}
