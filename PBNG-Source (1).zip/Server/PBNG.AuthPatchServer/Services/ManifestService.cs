using System.Security.Cryptography;
using System.Text.Json;
using PBNG.AuthPatchServer.Models;
namespace PBNG.AuthPatchServer.Services;
public sealed class ManifestService {
    private readonly IWebHostEnvironment _env;
    private static readonly JsonSerializerOptions Options = new() { PropertyNameCaseInsensitive = true };
    public ManifestService(IWebHostEnvironment env)=>_env=env;
    public PatchManifest Load(){ var p=Path.Combine(_env.ContentRootPath,"PatchFiles","manifest.json"); return JsonSerializer.Deserialize<PatchManifest>(File.ReadAllText(p), Options) ?? throw new InvalidOperationException("Invalid manifest"); }
}
