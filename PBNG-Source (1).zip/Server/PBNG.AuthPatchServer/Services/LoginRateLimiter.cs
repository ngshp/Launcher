using System.Collections.Concurrent;

namespace PBNG.AuthPatchServer.Services;

/// <summary>
/// Sebelumnya /api/auth/login bisa dicoba tanpa batas — rawan brute-force
/// menebak password. Sekarang dikunci sementara (lockout) kalau gagal
/// terlalu banyak kali dalam periode singkat, per kombinasi username+IP.
///
/// Ini penyimpanan in-memory sederhana (cukup untuk satu instance server).
/// Untuk server yang di-scale ke banyak instance sekaligus, ganti dengan
/// penyimpanan bersama seperti Redis.
/// </summary>
public sealed class LoginRateLimiter
{
    private const int MaxAttempts = 5;
    private static readonly TimeSpan LockoutWindow = TimeSpan.FromMinutes(5);

    private sealed class Entry
    {
        public int FailedAttempts;
        public DateTime FirstFailureUtc;
        public DateTime? LockedUntilUtc;
    }

    private readonly ConcurrentDictionary<string, Entry> _entries = new();

    private static string Key(string username, string ip) => $"{username.ToLowerInvariant()}|{ip}";

    public bool IsLockedOut(string username, string ip, out TimeSpan retryAfter)
    {
        retryAfter = TimeSpan.Zero;
        if (!_entries.TryGetValue(Key(username, ip), out var entry)) return false;

        if (entry.LockedUntilUtc is { } lockedUntil && lockedUntil > DateTime.UtcNow)
        {
            retryAfter = lockedUntil - DateTime.UtcNow;
            return true;
        }
        return false;
    }

    public void RecordFailure(string username, string ip)
    {
        var entry = _entries.GetOrAdd(Key(username, ip), _ => new Entry { FirstFailureUtc = DateTime.UtcNow });

        if (DateTime.UtcNow - entry.FirstFailureUtc > LockoutWindow)
        {
            entry.FailedAttempts = 0;
            entry.FirstFailureUtc = DateTime.UtcNow;
            entry.LockedUntilUtc = null;
        }

        entry.FailedAttempts++;
        if (entry.FailedAttempts >= MaxAttempts)
        {
            entry.LockedUntilUtc = DateTime.UtcNow.Add(LockoutWindow);
        }
    }

    public void RecordSuccess(string username, string ip)
    {
        _entries.TryRemove(Key(username, ip), out _);
    }
}
